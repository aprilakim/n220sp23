/*April Kim
2 March 2023
N220
*/

let newTicker = document.getElementById("ticker");


function addTicks(){
    newTicker.innerHTML += " toc";
    newTicker.innerHTML += " tick";


}